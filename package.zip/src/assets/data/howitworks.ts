export const HOWITWORK_DETAILS_ONE = [{
        "id": 1,
        "hiw": "Post Project",
        "imageUrl":"assets/img/color-icon/Post-Project.png",
        "description": "Lorem ipsum dolor sit amet,consectetur adipiscing elit.",
    },
    {
        "id": 2,
        "hiw": "Recommendation",
        "imageUrl":"assets/img/color-icon/Recommendations.png",
        "description": "Lorem ipsum dolor sit amet,consectetur adipiscing elit.",
    },
    {
        "id": 3,
        "hiw": "Live Chat",
        "imageUrl":"assets/img/color-icon/Live chat.png",
        "description": "Lorem ipsum dolor sit amet,consectetur adipiscing elit.",
    },
    {
        "id": 4,
        "hiw": "Review, Approve & Pay",
        "imageUrl":"assets/img/color-icon/Review & Approve.png",
        "description": "Lorem ipsum dolor sit amet,consectetur adipiscing elit.",
    },
    {
        "id": 5,
        "hiw": "Review & Ratings",
        "imageUrl":"assets/img/color-icon/Review & Ratings.png",
        "description": "Lorem ipsum dolor sit amet,consectetur adipiscing elit.",
    }]


export const CATEGORY_DETAILS = [{
        "id": 1,
        "hiw": "Post Project",
        "imageUrl":"assets/img/color-icon/Post-Project.png",
        "description": "Lorem ipsum dolor sit amet, consectetur adipiscing elit,",
    },
    {
        "id": 2,
        "hiw": "Recommendation ",
        "imageUrl":"assets/img/color-icon/Recommendations.png",
        "description": "Lorem ipsum dolor sit amet, consectetur adipiscing elit, ut labore et dolore magna aliqua. Lorem ipsum dolor sit amet, consectetur adipiscing elit, ut labore et dolore magna aliqua. Lorem ipsum dolor sit amet, consectetur adipiscing elit, ut labore et dolore magna aliqua. Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.",
    },
    {
        "id": 3,
        "hiw": "Live Chat",
        "imageUrl":"assets/img/color-icon/Live chat.png",
        "description": "Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.",
      
    },
    {
        "id": 4,
        "hiw": "Review, Approve & Pay",
        "imageUrl":"assets/img/color-icon/Review & Approve.png",
        "description": "Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.",
    },
    {
        "id": 5,
        "hiw": "Review & Ratings",
        "imageUrl":"assets/img/color-icon/Review & Ratings.png",
        "description": "Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.",
    }
]