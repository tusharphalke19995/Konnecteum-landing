import { Component, OnInit } from '@angular/core';
import { CATEGORY_DETAILS_ONE, CATEGORY_DETAILS_TWO } from 'src/assets/data/category';
import { HOWITWORK_DETAILS_ONE } from 'src/assets/data/howitworks';

@Component({
  selector: 'app-how-we-work',
  templateUrl: './how-we-work.component.html',
  styleUrls: ['./how-we-work.component.scss']
})
export class HowWeWorkComponent implements OnInit {

  howItWork = HOWITWORK_DETAILS_ONE;

  constructor() { }

  ngOnInit() {}

  

}

