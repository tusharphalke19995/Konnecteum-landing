import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-services-two',
  templateUrl: './services-two.component.html',
  styleUrls: ['./services-two.component.scss']
})
export class ServicesTwoComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
