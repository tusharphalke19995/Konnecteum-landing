import { NONE_TYPE } from '@angular/compiler';
import { ChangeDetectorRef, Component, NgZone, OnInit } from '@angular/core';
declare let $: any;
@Component({
  selector: 'app-work',
  templateUrl: './work.component.html',
  styleUrls: ['./work.component.scss']
})
export class WorkComponent implements OnInit {

  constructor(private ngZone: NgZone) { }

  public currentPage : any ;
  public currentIndex : any ;
  public currentTarget : any ;
  ngOnInit() {
    let that=this;
    this.currentPage = -1;
    console.log("currentPage", this.currentPage);

    var owl = $('.owl-carousel');
    console.log("owl", owl);
    $('.owl-carousel').owlCarousel({
      autoplay: true,
      center: true,
      loop: true,
      nav: true,
      items : 1, 
      itemsDesktop : false,
      itemsDesktopSmall : false,
      itemsTablet: false,
      itemsMobile : false,
      onClick : function callback(event: any){
        console.log("event onClick", event);
      },
      onChange: function callback(event: any) {
        console.log("event", event);
        
        let page = event.page.index;
        that.currentPage = page;
        console.log("currentPage", that.currentPage);
        var item = event.item.index;
        that.currentIndex = item;
        console.log("that.currentIndex", that.currentIndex);
        var element = event.target;
        that.currentTarget = element ;
        console.log("that.currentTarget", that.currentIndex);
      }
    });
    
  }

  // callback(event: any) {
    
  //   // Provided by the core
  //   var element = event.target;         // DOM element, in this example .owl-carousel
  //   var name = event.type;           // Name of the event, in this example dragged
  //   var namespace = event.namespace;      // Namespace of the event, in this example owl.carousel
  //   var items = event.item.count;     // Number of items
  //   var item = event.item.index;     // Position of the current item
  //   // Provided by the navigation plugin
  //   var pages = event.page.count;     // Number of pages
  //   let page = event.page.index;     // Position of the current page

  //   var size = event.page.size;      // Number of items per page
  //   console.log("page", page);
   
  //   this.currentPage = page;
  //   console.log("currentPage i", this.currentPage);
  //   // this.changePage(page);
  // }
 
   changePage(page){
    this.currentPage = page;
    console.log("currentPage", this.currentPage);
  }

}
